<?php

require_once 'controllers/OrderController.php';
require_once 'config/db.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");


$database = new Database();
$db = $database->getConnection();

$orderController = new OrderController($db);

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        if (isset($_GET['id'])) {
            $orderController->readSingle();
        } else {
            $orderController->read();
        }
        break;
    case 'POST':
        $orderController->create();
        break;
    case 'PUT':
        $orderController->update();
        break;
    case 'DELETE':
        $orderController->delete();
        break;
    default:
        echo json_encode(["message" => "Invalid method."]);
        break;
}
