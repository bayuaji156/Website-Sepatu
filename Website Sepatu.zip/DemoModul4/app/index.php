<?php
// Routing file
require_once 'routes/api.php';
