<?php

require_once 'models/Order.php';

class OrderController {
    private $db;
    private $order;

    public function __construct($db) {
        $this->db = $db;
        $this->order = new Order($db);
    }

    public function create() {
        $data = json_decode(file_get_contents("php://input"));

        if (!empty($data->customerName) && !empty($data->phoneNumber) && !empty($data->email) && !empty($data->shoeSelect) && !empty($data->shoeSize) && !empty($data->deliveryAddress)) {
            $this->order->customerName = htmlspecialchars(strip_tags($data->customerName));
            $this->order->phoneNumber = htmlspecialchars(strip_tags($data->phoneNumber));
            $this->order->email = htmlspecialchars(strip_tags($data->email));
            $this->order->shoeSelect = htmlspecialchars(strip_tags($data->shoeSelect));
            $this->order->shoeSize = htmlspecialchars(strip_tags($data->shoeSize));
            $this->order->deliveryAddress = htmlspecialchars(strip_tags($data->deliveryAddress));

            if ($this->order->create()) {
                echo json_encode(["message" => "Order created successfully."]);
            } else {
                echo json_encode(["message" => "Unable to create order."]);
            }
        } else {
            echo json_encode(["message" => "Incomplete data."]);
        }
    }

    public function read() {
        $stmt = $this->order->read();
        $orders = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $orders[] = [
                "id" => $id,
                "customerName" => $customerName,
                "phoneNumber" => $phoneNumber,
                "email" => $email,
                "shoeSelect" => $shoeSelect,
                "shoeSize" => $shoeSize,
                "deliveryAddress" => $deliveryAddress,
                "createdAt" => $createdAt
            ];
        }

        echo json_encode($orders);
    }

    public function readSingle() {
        $this->order->id = $_GET['id'];
        $stmt = $this->order->readSingle();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            extract($row);
            $order = [
                "id" => $id,
                "customerName" => $customerName,
                "phoneNumber" => $phoneNumber,
                "email" => $email,
                "shoeSelect" => $shoeSelect,
                "shoeSize" => $shoeSize,
                "deliveryAddress" => $deliveryAddress,
                "createdAt" => $createdAt
            ];
            echo json_encode($order);
        } else {
            echo json_encode(["message" => "Order not found."]);
        }
    }

    public function update() {
        $data = json_decode(file_get_contents("php://input"));

        if (empty($data->id) || empty($data->customerName) || empty($data->phoneNumber) || empty($data->email) || empty($data->shoeSelect) || empty($data->shoeSize) || empty($data->deliveryAddress)) {
            echo json_encode(["message" => "Incomplete data."]);
            return;
        }

        $this->order->id = $data->id;
        $this->order->customerName = htmlspecialchars(strip_tags($data->customerName));
        $this->order->phoneNumber = htmlspecialchars(strip_tags($data->phoneNumber));
        $this->order->email = htmlspecialchars(strip_tags($data->email));
        $this->order->shoeSelect = htmlspecialchars(strip_tags($data->shoeSelect));
        $this->order->shoeSize = htmlspecialchars(strip_tags($data->shoeSize));
        $this->order->deliveryAddress = htmlspecialchars(strip_tags($data->deliveryAddress));

        if ($this->order->update()) {
            echo json_encode(["message" => "Order updated successfully."]);
        } else {
            echo json_encode(["message" => "Unable to update order."]);
        }
    }

    public function delete() {
        $data = json_decode(file_get_contents("php://input"));
        if (empty($data->id)) {
            echo json_encode(["message" => "Order ID is required."]);
            return;
        }

        $this->order->id = $data->id;

        if ($this->order->delete()) {
            echo json_encode(["message" => "Order deleted successfully."]);
        } else {
            echo json_encode(["message" => "Unable to delete order."]);
        }
    }
}
