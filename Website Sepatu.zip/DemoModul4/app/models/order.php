<?php

class Order {
    private $conn;
    private $table_name = "orders";

    public $id;
    public $customerName;
    public $phoneNumber;
    public $email;
    public $shoeSelect;
    public $shoeSize;
    public $deliveryAddress;
    public $createdAt;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Create a new order
    public function create() {
        // Set timezone to Asia/Jakarta
        date_default_timezone_set('Asia/Jakarta');
        
        // Get current date and time in Jakarta timezone
        $this->createdAt = date('Y-m-d H:i:s');

        $query = "INSERT INTO " . $this->table_name . " 
                  SET customerName=:customerName, phoneNumber=:phoneNumber, email=:email, 
                  shoeSelect=:shoeSelect, shoeSize=:shoeSize, deliveryAddress=:deliveryAddress, createdAt=:createdAt";

        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->customerName = htmlspecialchars(strip_tags($this->customerName));
        $this->phoneNumber = htmlspecialchars(strip_tags($this->phoneNumber));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->shoeSelect = htmlspecialchars(strip_tags($this->shoeSelect));
        $this->shoeSize = htmlspecialchars(strip_tags($this->shoeSize));
        $this->deliveryAddress = htmlspecialchars(strip_tags($this->deliveryAddress));

        // Bind data
        $stmt->bindParam(":customerName", $this->customerName);
        $stmt->bindParam(":phoneNumber", $this->phoneNumber);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":shoeSelect", $this->shoeSelect);
        $stmt->bindParam(":shoeSize", $this->shoeSize);
        $stmt->bindParam(":deliveryAddress", $this->deliveryAddress);
        $stmt->bindParam(":createdAt", $this->createdAt);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    // Get all orders
    public function read() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY createdAt DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }

    // Get a single order by ID
    public function readSingle() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id LIMIT 0,1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->execute();

        return $stmt;
    }

    // Update an existing order
    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                  SET customerName=:customerName, phoneNumber=:phoneNumber, email=:email, 
                  shoeSelect=:shoeSelect, shoeSize=:shoeSize, deliveryAddress=:deliveryAddress
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->customerName = htmlspecialchars(strip_tags($this->customerName));
        $this->phoneNumber = htmlspecialchars(strip_tags($this->phoneNumber));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->shoeSelect = htmlspecialchars(strip_tags($this->shoeSelect));
        $this->shoeSize = htmlspecialchars(strip_tags($this->shoeSize));
        $this->deliveryAddress = htmlspecialchars(strip_tags($this->deliveryAddress));

        // Bind data
        $stmt->bindParam(":customerName", $this->customerName);
        $stmt->bindParam(":phoneNumber", $this->phoneNumber);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":shoeSelect", $this->shoeSelect);
        $stmt->bindParam(":shoeSize", $this->shoeSize);
        $stmt->bindParam(":deliveryAddress", $this->deliveryAddress);
        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }

    // Delete an order
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        $this->id = htmlspecialchars(strip_tags($this->id));

        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        }

        return false;
    }
}
